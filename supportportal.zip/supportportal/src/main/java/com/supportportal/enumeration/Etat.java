package com.supportportal.enumeration;

public enum Etat {
    IN_PROGRESS,
    Completed,

    Pending



}
