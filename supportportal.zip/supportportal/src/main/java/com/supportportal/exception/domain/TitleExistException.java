package com.supportportal.exception.domain;

public class TitleExistException extends Exception {
    public TitleExistException(String message) {
        super(message);
    }
}
