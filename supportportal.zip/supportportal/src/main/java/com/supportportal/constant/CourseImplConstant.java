package com.supportportal.constant;

public class CourseImplConstant {
    public static final String TITLE_ALREADY_EXISTS = "Title already exists";
    public static final String NO_COURSE_FOUND_BY_TITLE = "No course found by  this title : ";
    public static final String FOUND_COURSE_BY_TITLE = "Returning found course by title: ";
}
