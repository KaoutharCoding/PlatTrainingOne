package com.supportportal.exception.domain;

public class FormationNameAlreadyExistsException extends Exception {
    public FormationNameAlreadyExistsException(String message) {
        super(message);
    }
}

