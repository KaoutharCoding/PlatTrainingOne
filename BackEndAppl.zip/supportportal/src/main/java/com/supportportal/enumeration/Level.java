package com.supportportal.enumeration;

public enum Level {
    Beginner,
    Elementary,
    Intermediate,
    Advanced,
    Proficient
}
