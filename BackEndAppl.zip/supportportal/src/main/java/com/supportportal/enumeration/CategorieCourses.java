package com.supportportal.enumeration;

public enum CategorieCourses {

    CloudComputing,
    Security,
    PLM,
    DataScience;


}
