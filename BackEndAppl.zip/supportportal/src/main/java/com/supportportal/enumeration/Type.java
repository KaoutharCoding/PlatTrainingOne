package com.supportportal.enumeration;

public enum Type {
    General,
    Specific

}
