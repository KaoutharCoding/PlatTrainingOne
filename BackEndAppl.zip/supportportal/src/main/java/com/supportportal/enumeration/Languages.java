package com.supportportal.enumeration;

public enum Languages {
    French,
    English
}
