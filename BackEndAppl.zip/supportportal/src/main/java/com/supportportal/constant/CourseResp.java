package com.supportportal.constant;

public class CourseResp {
    public static final String COURSE_SUCCESSFULLY_DELETED = "this course has deleted";
    public static final String  TITLE_ALREADY_EXIST= "Title already exist,try another one please";
}
