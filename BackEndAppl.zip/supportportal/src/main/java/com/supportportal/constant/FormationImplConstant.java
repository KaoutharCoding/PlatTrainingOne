package com.supportportal.constant;

public class FormationImplConstant {
    public static final String TITLE_ALREADY_EXISTS = "Title already exists";
    public static final String NO_COURSE_FOUND_BY_TITLE = "No formation found by  this title : ";
    public static final String FOUND_COURSE_BY_TITLE = "Returning found course by title: ";
}
